This solution is provided as is by coursera once you finish the course to cross check your code with.

BUT

to implement this in your code requires some changes.
So if you want to directly copy paste go for my solution (The folder with By Aman in its name), it gives you 90% pass, 9/10 test cases.
If you have free time and want to go for 100% then implement this one.