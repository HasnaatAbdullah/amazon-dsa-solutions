import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Initialize core components
        Library library = new Library();
        LibrarySerializer serializer = new LibrarySerializer();

        // Attempt to load saved library data
        List<Book> savedBooks = serializer.loadLibrary("library.ser");
        if (savedBooks != null) {
            library.setBooks(savedBooks);
            System.out.println("Library loaded from saved data");
        } 
        // Fallback to default books if no saved data exists
        else {
            System.out.println("Warning: No saved library found - loading default books");
            library.loadBooks("books.txt");
            
            // Verify successful load
            if (library.getBooks().isEmpty()) {
                System.err.println("Error: Could not load default books");
                return;
            }
        }

        // Launch the interactive menu
        new LibraryMenu(library).displayMenu();
    }
}