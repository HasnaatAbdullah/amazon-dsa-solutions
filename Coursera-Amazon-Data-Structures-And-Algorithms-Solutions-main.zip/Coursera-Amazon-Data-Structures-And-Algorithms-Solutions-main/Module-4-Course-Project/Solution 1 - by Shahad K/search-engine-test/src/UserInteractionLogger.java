import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

public class UserInteractionLogger {
    private static final String LOG_FILE = "user_interactions.log";

    public void log(String message) {
        try (FileWriter writer = new FileWriter(LOG_FILE, true)) {
            writer.write(LocalDateTime.now() + " - " + message + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void logSearch(String keyword) {
        log("Search for: " + keyword);
    }

    public void logSort(String criteria) {
        log("Sorted by: " + criteria);
    }
}