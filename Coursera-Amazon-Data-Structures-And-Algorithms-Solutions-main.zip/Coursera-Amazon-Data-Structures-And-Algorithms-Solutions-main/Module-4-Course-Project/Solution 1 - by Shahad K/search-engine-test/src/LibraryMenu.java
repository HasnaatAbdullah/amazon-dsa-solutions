import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class LibraryMenu {
    private Library library;
    private UserInteractionLogger logger;
    private LibrarySerializer serializer;

    public LibraryMenu(Library library) {
        this.library = library;
        this.logger = new UserInteractionLogger();
        this.serializer = new LibrarySerializer();
    }

    public void displayMenu() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== Main Menu ===");
            System.out.println("1. View All Books");
            System.out.println("2. Sort Books by Title");
            System.out.println("3. Sort Books by Author");
            System.out.println("4. Search for a Book");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    library.viewAllBooks();
                    logger.log("Viewed all books");
                    break;
                case "2":
                    sortBooks(Comparator.comparing(Book::getTitle), "title");
                    break;
                case "3":
                    sortBooks(Comparator.comparing(Book::getAuthor), "author");
                    break;
                case "4":
                    searchForBook(scanner);
                    break;
                case "5":
                    exitProgram();
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private void sortBooks(Comparator<Book> comparator, String criteria) {
        List<Book> books = library.getBooks();
        if (books != null) {
            books.sort(comparator);
            logger.logSort(criteria);
            System.out.println("Books sorted by " + criteria + ".");
        }
    }

    private void searchForBook(Scanner scanner) {
        System.out.print("Enter keyword: ");
        String keyword = scanner.nextLine();
        Book found = library.searchBookByKeyword(keyword);
        if (found != null) {
            System.out.println("Found: " + found);
            logger.logSearch(keyword);
        } else {
            System.out.println("No matches found.");
        }
    }

    private void exitProgram() {
        serializer.saveLibrary(library.getBooks(), "library.ser");
        logger.log("Exited program");
        System.out.println("Goodbye!");
    }
}